﻿Public Class form1
    Private dailyCharge As Decimal
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cbmVehicleType.Items.Add("Sedan")
        cbmVehicleType.Items.Add("SUV")
        cbmVehicleType.Items.Add("Truck")

        cbmVehicleType.SelectedIndex = -1
    End Sub
    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbmVehicleType.SelectedIndexChanged
        If cbmVehicleType.SelectedIndex = -1 Then
            txtDailyRate.Clear()
            dailyCharge = 0
        End If
        Select Case cbmVehicleType.SelectedItem.ToString()
            Case "Sedan"
                dailyCharge = 150000
            Case "SUV"
                dailyCharge = 290000
            Case "Truck"
                dailyCharge = 350000
            Case Else
                dailyCharge = 0
        End Select

        txtDailyRate.Text = dailyCharge.ToString("N0")
    End Sub
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        If String.IsNullOrEmpty(txtDuration.Text) Then
            MessageBox.Show("Please enter the rental duration in days.", "Invalid Required",
MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtDuration.Focus()
        End If
        Dim daysRented As Integer
        If Not Integer.TryParse(txtDuration.Text, daysRented) Then
            MessageBox.Show("Please enter a valid number for days.", "Invalid Input",
                            MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtDuration.Clear()
            txtDuration.Focus()
        End If

        If daysRented <= 0 Then
            MessageBox.Show("please enter a number greater than 0.", "Invalid Input",
MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtDuration.Clear()
            txtDuration.Focus()
        End If

        Dim totalCost As Decimal = dailyCharge * daysRented
        txtTotalCost.Text = totalCost.ToString("N0")
    End Sub
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Dim result As DialogResult = MessageBox.Show(
            "Are you sure you want to exit?",
"Exit Confirmation",
MessageBoxButtons.YesNo,
MessageBoxIcon.Question,
MessageBoxDefaultButton.Button2
)
        If result = DialogResult.Yes Then
            Application.Exit()
        End If
    End Sub

    Private Sub btnClear_Click_1(sender As Object, e As EventArgs) Handles btnClear.Click
        cbmVehicleType.SelectedIndex = 0
        txtDuration.Clear()
        txtDailyRate.Clear()
        txtTotalCost.Clear()


        dailyCharge = 0
    End Sub
End Class
